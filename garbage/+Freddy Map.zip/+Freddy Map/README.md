gloomy's mod
please don't steal or repost anything :(
